## 1.1.0

- Added RiskOfOptions Dependency
- Created Config through RiskOfOptions for customizing arrow colors
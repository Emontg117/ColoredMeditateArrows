# Colored Meditate Arrows

This mod color changes the color of the arrows that display during Seeker's Meditate ability to make them easier to read.